#!/bin/bash
# Hash every protocol-governing artefact. Nothing produced AFTER this may change them.
# A validation run is only admissible if these hashes still match.
set -euo pipefail
cd /opt/sptb
OUT=FROZEN.json
FILES="run/decision_rule.py run/inject.py run/campaign.sh run/verify_frozen.sh run/scenarios.sh run/topology.sh run/start.sh run/stop.sh run/flood.py run/pmc_log.sh run/window_features.py run/evaluate.py run/baseline_floor.py cfg/g87251.base ptp_deep_extract.py"
echo "{" > $OUT
echo "  \"frozen_utc\": \"$(date -u +%Y-%m-%dT%H:%M:%SZ)\"," >> $OUT
echo "  \"development_set\": [\"baseline\",\"A1_rogue_master\",\"B2_gm_failover\",\"B3_pdv_congestion\",\"A2_sync_spoof\",\"A3_replay\",\"A5_dos_flood\",\"A8_rogue_bc\",\"B7_topology_change\"],
  \"development_reps\": [1,2,3,4,5,6,7,10,11,12,13]," >> $OUT
echo "  \"development_set_note\": \"Rep-1 of every scenario exposed a Delay_Resp sequenceId keying defect (799 false regressions on a healthy baseline). Rule fixed and re-frozen. ALL rep-1 runs are development data and are EXCLUDED from reported results.\"," >> $OUT
echo "  \"validation_rule\": \"Only runs created after frozen_utc, with all hashes matching, are admissible as evidence.\"," >> $OUT
echo "  \"artifacts\": {" >> $OUT
first=1
for f in $FILES; do
  [ -f "$f" ] || continue
  h=$(sha256sum "$f" | cut -d' ' -f1); b=$(stat -c%s "$f")
  [ $first -eq 1 ] && first=0 || echo "," >> $OUT
  printf '    "%s": {"sha256":"%s","bytes":%s}' "$f" "$h" "$b" >> $OUT
done
echo "" >> $OUT; echo "  }" >> $OUT; echo "}" >> $OUT
echo "FROZEN -> $OUT"; python3 -c "import json;d=json.load(open('/opt/sptb/FROZEN.json'));print(len(d['artifacts']),'artefacts hashed')"
