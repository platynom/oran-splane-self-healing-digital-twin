#!/usr/bin/env python3
"""
Session-disjoint evaluation of the FROZEN decision rule.

* Development-set runs (named in FROZEN.json) are EXCLUDED from every reported figure.
* Splits are by RUN, never by window - a window from a run may not appear on both sides.
* Reports sensitivity/specificity with Wilson 95% CIs and an explicit UNKNOWN count.
* If a class has too few runs, it reports NOT ESTABLISHED (interval width) quoting both
  point estimates and both class sizes - it never prints a bare "fails threshold".
"""
from __future__ import annotations
import json, os, glob, math, sys, collections

def wilson(k,n,z=1.96):
    if n==0: return (None,None,None)
    p=k/n; d=1+z*z/n; c=(p+z*z/(2*n))/d
    h=z*math.sqrt(p*(1-p)/n+z*z/(4*n*n))/d
    return (round(p,4),round(max(0,c-h),4),round(min(1,c+h),4))

def main(cap_root="/opt/sptb/cap", frozen="/opt/sptb/FROZEN.json"):
    # Development data is identified by REPLICATE NUMBER, not scenario name. Reps 1-2
    # exposed rule defects and were discarded; every rep after the final freeze is
    # admissible. Excluding by scenario name would discard the entire campaign.
    dev_reps=set()
    if os.path.exists(frozen):
        dev_reps=set(json.load(open(frozen)).get("development_reps",[]))
    runs=[]
    for d in sorted(glob.glob(os.path.join(cap_root,"*"))):
        cj,dj=os.path.join(d,"context.json"),os.path.join(d,"decision.json")
        if not (os.path.exists(cj) and os.path.exists(dj)): continue
        ctx=json.load(open(cj)); dec=json.load(open(dj))
        base=os.path.basename(d)
        rep=None
        if "__r" in base:
            try: rep=int(base.split("__r")[-1])
            except ValueError: rep=None
        runs.append(dict(run=base,scenario=ctx["scenario"],rep=rep,
                         truth=ctx["class"],fault=ctx["fault_id"],
                         verdict=dec["verdict"],hint=dec.get("fault_hint"),
                         is_dev=(rep in dev_reps) or rep is None))
    val=[r for r in runs if not r["is_dev"]]
    excl=[r for r in runs if r["is_dev"]]
    att=[r for r in val if r["truth"]=="attack"]
    ben=[r for r in val if r["truth"] in ("benign","healthy")]
    tp=sum(1 for r in att if r["verdict"]=="ATTACK")
    fn=sum(1 for r in att if r["verdict"]=="BENIGN")
    ua=sum(1 for r in att if r["verdict"]=="UNKNOWN")
    tn=sum(1 for r in ben if r["verdict"]=="BENIGN")
    fp=sum(1 for r in ben if r["verdict"]=="ATTACK")
    ub=sum(1 for r in ben if r["verdict"]=="UNKNOWN")
    sens=wilson(tp,len(att)); spec=wilson(tn,len(ben))
    print("="*78)
    print("SESSION-DISJOINT EVALUATION OF THE FROZEN RULE")
    print("="*78)
    print(f"development/unnumbered runs EXCLUDED : {len(excl)}  reps={sorted(set(r['rep'] for r in excl))}")
    print(f"admissible replicates            : {sorted(set(r['rep'] for r in val))}")
    print(f"validation runs               : {len(val)}  (attack={len(att)}, benign={len(ben)})")
    if not val:
        print("\nNOT ESTABLISHED: zero admissible validation runs. Every run present was in the\n"
              "development set. Produce fresh runs AFTER the freeze before any figure is quoted.")
        return
    print(f"\nconfusion (attack): TP={tp} FN={fn} UNKNOWN={ua}")
    print(f"confusion (benign): TN={tn} FP={fp} UNKNOWN={ub}")
    def fmt(name,est,n):
        if n==0: return f"{name}: NOT ESTABLISHED (no runs in this class)"
        p,lo,hi=est
        w=hi-lo
        s=f"{name}: {p:.3f}  95% CI [{lo:.3f}, {hi:.3f}]  n={n}"
        if w>0.4: s+="  <- NOT ESTABLISHED (interval too wide; underpowered)"
        return s
    print("\n"+fmt("sensitivity (attack recall)",sens,len(att)))
    print(fmt("specificity (benign recall)",spec,len(ben)))
    if len(att)<8 or len(ben)<8:
        print(f"\nNOT ESTABLISHED (interval width): attack n={len(att)}, benign n={len(ben)}. "
              f"Point estimates are shown above but neither interval is tight enough to support a claim.")
    # multi-class attribution (does it name the RIGHT fault, not just "attack"?)
    att_ok=sum(1 for r in att if r["hint"]==r["fault"])
    a_est=wilson(att_ok,len(att))
    print("\n"+fmt("attack attribution accuracy (correct fault id)",a_est,len(att)))
    per=collections.defaultdict(lambda:[0,0])
    for r in att:
        per[r["fault"]][1]+=1
        if r["hint"]==r["fault"]: per[r["fault"]][0]+=1
    print("  per-fault:", "  ".join(f"{k}={v[0]}/{v[1]}" for k,v in sorted(per.items())))
    print("\nper-run detail:")
    for r in val:
        ok="OK " if (r["verdict"]=="ATTACK")==(r["truth"]=="attack") else ("UNK" if r["verdict"]=="UNKNOWN" else "ERR")
        print(f"  [{ok}] {r['run']:28s} truth={r['truth']:7s}/{str(r['fault']):5s} -> {r['verdict']:8s} ({r['hint']})")
    json.dump(dict(attribution_accuracy=a_est,per_fault={k:v for k,v in per.items()},excluded=[r['run'] for r in excl],validation=val,
                   tp=tp,fn=fn,unknown_attack=ua,tn=tn,fp=fp,unknown_benign=ub,
                   sensitivity=sens,specificity=spec),
              open("/opt/sptb/EVALUATION.json","w"),indent=2)
    print("\n-> /opt/sptb/EVALUATION.json")

if __name__=="__main__": main(*(sys.argv[1:] or []))
