#!/bin/bash
# Scenario library. Each scenario writes a context manifest + captures + per-node logs.
# All faults are produced ON THE WIRE against the real linuxptp testbed - none simulated.
set -uo pipefail
SC="$1"; DUR="${2:-60}"; OUT=/opt/sptb/cap/$SC; mkdir -p $OUT

# --- context manifest (ground truth + the CONTEXT axis: allow-list, topology, maintenance) ---
manifest(){ cat > $OUT/context.json <<J
{ "scenario":"$SC", "class":"$1", "fault_id":"$2",
  "gm_allowlist":["020000fffe00000a","020000fffe00000b"],
  "provisioned_backup_gm":"020000fffe00000b",
  "expected_bc_identity":"020000fffe000001",
  "expected_client_identities":["020000fffe00000c","020000fffe00000d","020000fffe00000e"],
  "expected_steps_removed_at_ru":1,
  "maintenance_window_open":$3,
  "description":"$4" }
J
}
start_clean(){ /opt/sptb/run/start.sh $SC >/dev/null 2>&1; }
stop_all(){ /opt/sptb/run/stop.sh $SC >/dev/null 2>&1; }

case "$SC" in
 baseline)
   manifest healthy none false "All nodes nominal, GM-A grandmaster via BC to RUs"
   start_clean; sleep $DUR; stop_all ;;
 A1_rogue_master)
   manifest attack A1 false "Rogue ptp4l on RU segment advertises superior priority2=1, NOT on allow-list"
   start_clean; sleep 25
   # rogue: an identity NOT in the allow-list, superior priority2, injected on the RU segment
   cat /opt/sptb/cfg/g87251.base > /opt/sptb/cfg/rogue.cfg
   printf "\npriority2                       1\nclockClass                      6\n[v-rogue]\nserverOnly                      1\n" >> /opt/sptb/cfg/rogue.cfg
   ip netns add rogue 2>/dev/null||true
   ip link add v-rogue type veth peer name p-rogue; ip link set p-rogue master brDN; ip link set p-rogue up
   ip link set v-rogue netns rogue
   ip netns exec rogue ip link set lo up
   ip netns exec rogue ip link set v-rogue address 02:00:00:00:00:66
   ip netns exec rogue ip link set v-rogue up
   ip netns exec rogue ptp4l -f /opt/sptb/cfg/rogue.cfg -i v-rogue -m --uds_address=/var/run/p.rogue --uds_ro_address=/var/run/pr.rogue >$OUT/rogue.log 2>&1 & echo $! >$OUT/rogue.pid
   sleep $((DUR-25)); [ -f $OUT/rogue.pid ] && kill $(cat $OUT/rogue.pid) 2>/dev/null
   stop_all; ip netns del rogue 2>/dev/null||true; ip link del v-rogue 2>/dev/null||true ;;
 B2_gm_failover)
   manifest benign B2 true "PLANNED: GM-A withdrawn (maintenance), GM-B (on allow-list) takes over via BMCA"
   start_clean; sleep 30
   # planned withdrawal of GM-A -> BMCA elects GM-B (the PROVISIONED backup)
   [ -f $OUT/gma.pid ] && kill $(cat $OUT/gma.pid) 2>/dev/null
   sleep $((DUR-30)); stop_all ;;
 B3_pdv_congestion)
   manifest benign B3 false "netem delay+jitter on the RU segment (congestion), no protocol anomaly"
   start_clean; sleep 20
   ip netns exec ru1 tc qdisc add dev v-ru1 root netem delay 5ms 3ms distribution normal 2>/dev/null||true
   ip netns exec ru2 tc qdisc add dev v-ru2 root netem delay 5ms 3ms distribution normal 2>/dev/null||true
   sleep $((DUR-20)); stop_all ;;
 A5_dos_flood)
   manifest attack A5 false "High-rate PTP Announce flood on RU segment from off-allow-list source"
   start_clean; sleep 25
   ip netns exec ru3 python3 /opt/sptb/run/flood.py v-ru3 $((DUR-25)) >$OUT/flood.log 2>&1 &
   FL=$!; sleep $((DUR-25)); kill $FL 2>/dev/null; stop_all ;;

 A2_sync_spoof)
   manifest attack A2 false "Forged Sync/Follow_Up injected on RU segment with manipulated originTimestamp"
   start_clean; sleep 25
   ip netns exec ru3 python3 /opt/sptb/run/inject.py v-ru3 sync $((DUR-25)) >$OUT/inject.log 2>&1 &
   IJ=$!; sleep $((DUR-25)); kill $IJ 2>/dev/null; stop_all ;;
 A3_replay)
   manifest attack A3 false "Captured Announce/Sync frames retransmitted later (stale timestamps, reused sequenceId)"
   start_clean; sleep 20
   # capture a slice from the live segment, then replay it back onto the wire
   timeout 10 tcpdump -i brDN -w $OUT/replay_src.pcap -s0 -c 400 2>/dev/null || true
   sleep 5
   ip netns exec ru3 tcpreplay -i v-ru3 --loop=6 $OUT/replay_src.pcap >$OUT/replay.log 2>&1 || true
   sleep $((DUR-40)); stop_all ;;
 A8_rogue_bc)
   manifest attack A8 false "A genuine rogue BOUNDARY CLOCK inserted in the path: two ports, slaves upstream on brUP, masters downstream on brDN, RELAYING the real GM identity with its own stepsRemoved. Not on the provisioned BC inventory."
   start_clean; sleep 25
   cat /opt/sptb/cfg/g87251.base > /opt/sptb/cfg/rbc.cfg
   printf "\npriority2                       115\n[v-rbc-up]\nserverOnly                      0\n[v-rbc-dn]\nserverOnly                      1\n" >> /opt/sptb/cfg/rbc.cfg
   ip netns add rbc 2>/dev/null||true
   ip link add v-rbc-up type veth peer name p-rbc-up; ip link set p-rbc-up master brUP; ip link set p-rbc-up up
   ip link add v-rbc-dn type veth peer name p-rbc-dn; ip link set p-rbc-dn master brDN; ip link set p-rbc-dn up
   ip link set v-rbc-up netns rbc; ip link set v-rbc-dn netns rbc
   ip netns exec rbc ip link set lo up
   ip netns exec rbc ip link set v-rbc-up address 02:00:00:00:00:87
   ip netns exec rbc ip link set v-rbc-dn address 02:00:00:00:00:88
   ip netns exec rbc ip link set v-rbc-up up; ip netns exec rbc ip link set v-rbc-dn up
   ip netns exec rbc ptp4l -f /opt/sptb/cfg/rbc.cfg -i v-rbc-up -i v-rbc-dn -m --uds_address=/var/run/p.rbc --uds_ro_address=/var/run/pr.rbc >$OUT/rbc.log 2>&1 & echo $! >$OUT/rbc.pid
   sleep $((DUR-25)); [ -f $OUT/rbc.pid ] && kill $(cat $OUT/rbc.pid) 2>/dev/null
   stop_all; ip netns del rbc 2>/dev/null||true
   ip link del v-rbc-up 2>/dev/null||true; ip link del v-rbc-dn 2>/dev/null||true ;;
 B7_topology_change)
   manifest benign B7 true "PLANNED: RU3 link bounced and re-homed (maintenance) - stepsRemoved/path re-measured"
   start_clean; sleep 25
   ip netns exec ru3 ip link set v-ru3 down; sleep 8; ip netns exec ru3 ip link set v-ru3 up
   sleep $((DUR-33)); stop_all ;;
 *) echo "unknown scenario $SC"; exit 1 ;;
esac
echo "scenario $SC complete -> $OUT"
