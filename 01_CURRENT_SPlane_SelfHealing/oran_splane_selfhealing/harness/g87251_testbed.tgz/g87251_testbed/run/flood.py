import sys,time
from scapy.all import Ether,Raw,sendp
iface,dur=sys.argv[1],int(sys.argv[2])
# minimal PTP Announce-ish frame to the PTP multicast MAC at high rate
ptp=bytes([0x0b,0x02,0,0x40])+b"\x00"*60
pkt=Ether(dst="01:1b:19:00:00:00",src="02:00:00:00:00:77",type=0x88F7)/Raw(ptp)
t=time.time()
while time.time()-t<dur:
    sendp(pkt,iface=iface,count=200,verbose=0); time.sleep(0.05)
