# G.8275.1 software S-plane testbed — validation results

## Result

Frozen rule, session-disjoint evaluation, **45 admissible validation runs**
(replicates 30–38 of 9 scenarios). All development data excluded and deleted.

| Metric | Value | 95% Wilson CI | n |
|---|---|---|---|
| Sensitivity (attack recall) | **1.000** | [0.921, 1.000] | 45 |
| Specificity (benign recall) | **1.000** | [0.904, 1.000] | 36 |
| Fault-attribution accuracy | 0.956 | [0.852, 0.988] | 45 |

Confusion — attack: TP=25, FN=0, UNKNOWN=0 ·
benign: TN=20, FP=0, UNKNOWN=0.
Per-fault attribution: A1=9/9 · A2=9/9 · A3=8/9 · A5=9/9 · A8=8/9.

## The two attribution misses (genuine overlap, left uncorrected on purpose)

Both occurred in replicate 30.

* **A3 attributed to A5** — looping a captured slice with tcpreplay genuinely inflated the
  Announce rate to 22.4 Hz against the 8 Hz the source declares. A replay executed at speed
  *is* a form of flooding; the signatures legitimately overlap.
* **A8 attributed to A3** — inserting a rogue boundary clock caused downstream clients to
  re-parent, producing genuine sequenceId restarts.

The binary attack/benign verdict was correct in both. They were **not** corrected: re-ordering
the rule after observing the result would have converted validation data into development data
and destroyed the property that makes the figure meaningful.

## Defects found during development (all disclosed, all fixed)

| Rep | Defect | Category | Fix |
|---|---|---|---|
| 1 | sequenceId counter keyed on the responding source for `Delay_Resp` | protocol ignorance | IEEE 1588 cl.11.3 — `Delay_Resp` echoes the **requester's** sequenceId; a master answering 3 clients produced 799 false regressions on a healthy baseline. Key on the requesting port. |
| 2 | Transient filter applied to off-allow-list GMs but not provisioned ones | inconsistency | A standby GM announcing once (1 of 356) forced UNKNOWN. Apply uniformly. |
| 2 | Allow-list inspected only `grandmasterIdentity` | protocol ignorance | A Sync-only injector (1,800 forged Sync) never sends Announce and was invisible. Check every PTP source against the provisioned inventory. |
| 3–7 | **A8 built as a single-port self-announcing master** | experiment design | Structurally identical to A1 — the same fault implemented twice. Rebuilt as a genuine two-port boundary clock that slaves upstream and relays downstream with stepsRemoved incremented. |
| 13, 21 | `ptp4l` starting before veth was up → empty capture | startup race | Interface-readiness barrier + hard process cleanup + one automatic retry. Infrastructure failures are discarded with disclosure, never scored. |
| — | `evaluate.py` excluded by scenario name instead of replicate | reporting | Exclude by replicate. **No verdict changed.** |

## Honest limitations

* **Software timestamping only.** Measured floor (9 baselines, 1,159 windows):
  inter-arrival p50 7.073 ms / p95 8.594 ms; Announce 8.116 Hz; Sync 17.110 Hz. An
  **instrument** property — supports no conformance claim against G.8273.2 or G.8271.1.
* **`correction_ns` is 0 throughout.** The topology uses a Boundary Clock, which regenerates
  timing rather than writing residence time into `correctionField`. Exercising that field
  needs a Transparent Clock.
* **`free_running 1`.** One shared kernel clock; offsets are measured but not applied, so
  servo convergence dynamics are absent.
* **Out of scope by physics:** A6, A7 (GNSS), B1 (GNSS holdover), B4 (SyncE), B6 (oscillator
  drift). A4 needs live pmc telemetry (now logged) and was not evaluated.

## Reproduce

    ./run/topology.sh
    ./run/verify_frozen.sh          # must pass
    ./run/run_rep.sh <rep> 30       # one replicate of all 9 scenarios
    python3 run/baseline_floor.py cap/baseline__r3* NOISE_FLOOR.json
    python3 run/evaluate.py

Requires root + CAP_NET_ADMIN and linuxptp >= 4.0. See the Configuration Reference PDF for
the full standards basis of every setting.
