#!/usr/bin/env python3
"""Conformance NEGATIVE tests - Class A protocol-legality checks with STANDARDS-DEFINED
pass criteria (no calibration, no threshold-fitting). Each crafts a single non-conformant
Announce and asserts the frozen decision rule flags it, citing the exact standard clause.

These are deterministic: the standard states the rejection, so the expected result is fixed.
Covered (from the conformance catalogue / handoff §12.6):
  NEG-5   wrong domainNumber            UNH c.1.7 ; G.8275.1 domain 24-43
  NEG-3   stepsRemoved >= 255           UNH PWR.c.2.4
  NEG-2   alternateMasterFlag = TRUE    UNH PWR.c.2.5
  NEG-15  priority1 != 128              G.8275.1 (priority1 fixed 128)
  NEG-1   illegal clockClass (0-5)      IEEE 1588-2019 Table 5 (0-5 RESERVED)
  NEG-11  unicast / wrong multicast     G.8275.1 (multicast only)
Each writes a synthetic 1-row deep CSV with the offending field and a minimal legit
context, runs decision_rule.decide, and records verdict + which clause fired.
"""
import csv, json, os, sys, importlib.util

HERE=os.path.dirname(os.path.abspath(__file__))
spec=importlib.util.spec_from_file_location("dr", os.path.join(HERE,"decision_rule.py"))
dr=importlib.util.module_from_spec(spec); spec.loader.exec_module(dr)

COLS=["capture_ts_ns","eth_src","eth_dst","vlan_id","message_type","domain_number",
      "source_clock_identity","source_port_number","sequence_id","log_message_interval",
      "gm_priority1","gm_clock_class","gm_clock_identity","steps_removed",
      "g87251_mcast_ok","g87251_log_sync_ok","g87251_log_announce_ok",
      "gm_identity_equals_source","requesting_clock_identity","requesting_port_number",
      "flag_alternateMaster","minor_version_ptp"]

def base_announce(**over):
    # a legit, provisioned Announce row (GM-A). Overrides craft the violation.
    r={c:"" for c in COLS}
    r.update(capture_ts_ns="1000000000", eth_dst="011b19000000", message_type="Announce",
             domain_number="24", source_clock_identity="020000fffe00000a", source_port_number="1",
             sequence_id="1", log_message_interval="-3", gm_priority1="128", gm_clock_class="6",
             gm_clock_identity="020000fffe00000a", steps_removed="0",
             g87251_mcast_ok="1", g87251_log_sync_ok="1", g87251_log_announce_ok="1",
             gm_identity_equals_source="1")
    r.update(over); return r

CTX={"gm_allowlist":["020000fffe00000a","020000fffe00000b"],
     "provisioned_backup_gm":"020000fffe00000b","expected_bc_identity":"020000fffe000001",
     "expected_client_identities":["020000fffe00000c","020000fffe00000d","020000fffe00000e"],
     "expected_steps_removed_at_ru":1,"maintenance_window_open":False}

def run_case(name, rows, expect, clause):
    tmp="/tmp/cn.csv"
    with open(tmp,"w",newline="") as f:
        w=csv.DictWriter(f,fieldnames=COLS); w.writeheader()
        for r in rows: w.writerow(r)
    v,hint,why,ev=dr.decide(tmp,CTX)
    ok = (v==expect)
    return dict(case=name, clause=clause, expected=expect, verdict=v, fault_hint=hint,
                pass_=ok, reason=(why[0] if why else ""))

# legit sources need to be present so provenance checks have a baseline; add many legit
# announce so a single crafted one is >1% only when we want it sustained. For legality
# checks (domain/class/priority/mcast) even 1 packet must trip, per the standard.
LEGIT=[base_announce(sequence_id=str(i+1)) for i in range(50)]

cases=[
  run_case("NEG-5 wrong domain (0)", LEGIT+[base_announce(domain_number="0",sequence_id="900")],
           "ATTACK","G.8275.1 domain 24-43 / UNH c.1.7"),
  run_case("NEG-3 stepsRemoved 255", LEGIT+[base_announce(steps_removed="255",sequence_id="904")],
           "ATTACK","UNH PWR.c.2.4 (>=255 discard)"),
  run_case("NEG-15 priority1 != 128", LEGIT+[base_announce(gm_priority1="1",sequence_id="901")],
           "ATTACK","G.8275.1 priority1 fixed 128"),
  run_case("NEG-1 illegal clockClass 0", LEGIT+[base_announce(gm_clock_class="0",sequence_id="902")],
           "ATTACK","IEEE 1588-2019 Table 5 (0-5 reserved)"),
  run_case("NEG-11 wrong multicast", LEGIT+[base_announce(g87251_mcast_ok="0",eth_dst="0180c2000000",sequence_id="903")],
           "ATTACK","G.8275.1 multicast group"),
  run_case("NEG-2 alternateMasterFlag", LEGIT+[base_announce(flag_alternateMaster="1",sequence_id="905")],
           "ATTACK","UNH PWR.c.2.5 (alternateMasterFlag discard)"),
  # POSITIVE control: a fully-legit capture must be BENIGN
  run_case("CONTROL all-legit", LEGIT, "BENIGN","(no violation)"),
]

out={"conformance_negative_tests":cases,
     "passed":sum(1 for c in cases if c["pass_"]),"total":len(cases)}
print(json.dumps(out,indent=2))
json.dump(out,open("/opt/sptb/results/CONFORMANCE_NEG.json","w"),indent=2)
sys.exit(0 if out["passed"]==out["total"] else 1)
