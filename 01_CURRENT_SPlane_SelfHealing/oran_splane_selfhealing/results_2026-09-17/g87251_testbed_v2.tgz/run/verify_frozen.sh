#!/bin/bash
# Refuse to proceed if any frozen artefact changed.
set -euo pipefail
cd /opt/sptb
python3 - <<'PY'
import json,hashlib,os,sys
d=json.load(open("FROZEN.json")); bad=[]
for f,meta in d["artifacts"].items():
    if not os.path.exists(f): bad.append((f,"MISSING")); continue
    h=hashlib.sha256(open(f,'rb').read()).hexdigest()
    if h!=meta["sha256"]: bad.append((f,"CHANGED"))
if bad:
    print("FROZEN STATE VIOLATED:"); [print("  ",f,s) for f,s in bad]; sys.exit(1)
print(f"frozen state intact ({len(d['artifacts'])} artefacts) - runs are admissible")
PY
