#!/bin/bash
# Full campaign: verify frozen state -> run every scenario N times -> extract -> window -> decide.
# Refuses to run if any frozen artefact changed.
set -uo pipefail
REPS="${1:-10}"; DUR="${2:-70}"
cd /opt/sptb
./run/verify_frozen.sh || { echo "ABORT: frozen state violated"; exit 1; }
SCEN="baseline A1_rogue_master A2_sync_spoof A3_replay A5_dos_flood A8_rogue_bc B2_gm_failover B3_pdv_congestion B7_topology_change"
for i in $(seq 1 $REPS); do
  for s in $SCEN; do
    RUN="${s}__r${i}"
    ./run/topology.sh >/dev/null 2>&1
    # scenario writes to cap/$s ; redirect by temporarily pointing at a per-rep dir
    rm -rf cap/$RUN; mkdir -p cap/$RUN
    SC_ORIG=$s
    ./run/pmc_log.sh $SC_ORIG $DUR >/dev/null 2>&1 &
    PMC=$!
    ./run/scenarios.sh $SC_ORIG $DUR >/dev/null 2>&1
    wait $PMC 2>/dev/null
    cp -r cap/$SC_ORIG/. cap/$RUN/ 2>/dev/null
    python3 ptp_deep_extract.py cap/$RUN/dn.pcap cap/$RUN/${RUN}.dn.deep.csv >/dev/null 2>&1
    python3 run/window_features.py cap/$RUN >/dev/null 2>&1
    python3 run/decision_rule.py cap/$RUN >/dev/null 2>&1
    v=$(python3 -c "import json;print(json.load(open('cap/$RUN/decision.json'))['verdict'])" 2>/dev/null)
    echo "  rep$i $s -> $v"
  done
done
echo "=== campaign complete ==="
python3 run/baseline_floor.py $(ls -d cap/baseline__r* 2>/dev/null) /opt/sptb/NOISE_FLOOR.json
python3 run/evaluate.py
