#!/usr/bin/env python3
"""
Per-packet deep CSV -> windowed feature rows (what a detector actually consumes).

INTEGRITY: a feature that cannot be computed for a window is written EMPTY, never 0
and never a placeholder. Fields unavailable from a passive capture (the client's t2/t3,
hence true offset and directional path asymmetry) are NOT emitted at all.
"""
from __future__ import annotations
import csv, sys, os, collections, statistics, json

WINDOW_S, STEP_S = 0.4, 0.2     # matches the project's existing windowing

def f(x):
    try: return float(x)
    except: return None

def build(deep_csv, out_csv, scenario, label, fault_id):
    rows=[r for r in csv.DictReader(open(deep_csv)) if r.get("capture_ts_ns")]
    if not rows: return 0
    for r in rows: r["_t"]=int(r["capture_ts_ns"])/1e9
    rows.sort(key=lambda r:r["_t"])
    t0,t1=rows[0]["_t"],rows[-1]["_t"]
    cols=["scenario","label","fault_id","win_start_s","win_end_s","n_pkts","n_announce",
          "n_sync","n_followup","n_delayreq","n_delayresp",
          "msg_rate_hz","announce_rate_hz","sync_rate_hz",
          "n_gm_identities","n_source_identities","gm_identity_changes",
          "min_clock_class","max_clock_class","clock_class_changes",
          "min_priority1","min_priority2","steps_removed_min","steps_removed_max",
          "illegal_clock_class_pkts","bmca_all_zero_pkts","gm_self_announce_pkts",
          "seq_regressions","duplicate_seq_pkts",
          "correction_ns_mean","correction_ns_max","correction_nonzero_frac",
          "flag_timeTraceable_frac","flag_freqTraceable_frac","flag_twoStep_frac",
          "flag_leap_any_frac","utc_offset_mode",
          "domain_violation_pkts","mcast_violation_pkts",
          "cadence_sync_violation_pkts","cadence_announce_violation_pkts",
          "path_trace_frac","interarrival_ms_mean","interarrival_ms_std","telemetry_valid"]
    out=open(out_csv,"w",newline=""); w=csv.DictWriter(out,fieldnames=cols,extrasaction="ignore"); w.writeheader()
    n=0; t=t0
    while t < t1:
        win=[r for r in rows if t <= r["_t"] < t+WINDOW_S]
        t+=STEP_S
        if len(win)<2: continue
        ann=[r for r in win if r["message_type"]=="Announce"]
        mt=collections.Counter(r["message_type"] for r in win)
        gm=[r["gm_clock_identity"] for r in ann if r.get("gm_clock_identity")]
        cc=[int(r["gm_clock_class"]) for r in ann if r.get("gm_clock_class") not in ("",None)]
        p1=[int(r["gm_priority1"]) for r in ann if r.get("gm_priority1") not in ("",None)]
        p2=[int(r["gm_priority2"]) for r in ann if r.get("gm_priority2") not in ("",None)]
        sr=[int(r["steps_removed"]) for r in ann if r.get("steps_removed") not in ("",None)]
        corr=[f(r["correction_ns"]) for r in win if f(r.get("correction_ns")) is not None]
        ts=[r["_t"] for r in win]; ia=[(b-a)*1000 for a,b in zip(ts,ts[1:])]
        # sequence regressions per (source,type)
        # Delay_Resp echoes the REQUESTER's sequenceId (IEEE 1588) - key on the requester.
        bysrc=collections.defaultdict(list)
        for r in win:
            if r.get("sequence_id") in ("",None): continue
            if r["message_type"]=="Delay_Resp":
                owner=(r.get("requesting_clock_identity") or "",r.get("requesting_port_number") or "")
            else:
                owner=(r.get("source_clock_identity") or "",r.get("source_port_number") or "")
            bysrc[(owner,r["message_type"])].append(int(r["sequence_id"]))
        regs=sum(sum(1 for a,b in zip(v,v[1:]) if b<a and (a-b)<30000) for v in bysrc.values())
        dups=sum(len(v)-len(set(v)) for v in bysrc.values())
        chg=lambda seq: sum(1 for a,b in zip(seq,seq[1:]) if a!=b)
        dur=max(ts)-min(ts) or WINDOW_S
        utc=[r["current_utc_offset"] for r in ann if r.get("current_utc_offset") not in ("",None)]
        rec=dict(scenario=scenario,label=label,fault_id=fault_id,
            win_start_s=round(min(ts)-t0,4),win_end_s=round(max(ts)-t0,4),
            n_pkts=len(win),n_announce=len(ann),n_sync=mt.get("Sync",0),
            n_followup=mt.get("Follow_Up",0),n_delayreq=mt.get("Delay_Req",0),n_delayresp=mt.get("Delay_Resp",0),
            msg_rate_hz=round(len(win)/dur,3),
            announce_rate_hz=round(len(ann)/dur,3),sync_rate_hz=round(mt.get("Sync",0)/dur,3),
            n_gm_identities=len(set(gm)) if gm else "",
            n_source_identities=len(set(r["source_clock_identity"] for r in win)),
            gm_identity_changes=chg(gm) if gm else "",
            min_clock_class=min(cc) if cc else "",max_clock_class=max(cc) if cc else "",
            clock_class_changes=chg(cc) if cc else "",
            min_priority1=min(p1) if p1 else "",min_priority2=min(p2) if p2 else "",
            steps_removed_min=min(sr) if sr else "",steps_removed_max=max(sr) if sr else "",
            illegal_clock_class_pkts=sum(1 for r in ann if r.get("clock_class_legal")=="0"),
            bmca_all_zero_pkts=sum(1 for r in ann if r.get("bmca_fields_all_zero")=="1"),
            gm_self_announce_pkts=sum(1 for r in ann if r.get("gm_identity_equals_source")=="1"),
            seq_regressions=regs,duplicate_seq_pkts=dups,
            correction_ns_mean=round(statistics.fmean(corr),2) if corr else "",
            correction_ns_max=round(max(corr),2) if corr else "",
            correction_nonzero_frac=round(sum(1 for c in corr if c!=0)/len(corr),4) if corr else "",
            flag_timeTraceable_frac=round(sum(1 for r in win if r.get("flag_timeTraceable")=="1")/len(win),4),
            flag_freqTraceable_frac=round(sum(1 for r in win if r.get("flag_frequencyTraceable")=="1")/len(win),4),
            flag_twoStep_frac=round(sum(1 for r in win if r.get("flag_twoStep")=="1")/len(win),4),
            flag_leap_any_frac=round(sum(1 for r in win if r.get("flag_leap61")=="1" or r.get("flag_leap59")=="1")/len(win),4),
            utc_offset_mode=collections.Counter(utc).most_common(1)[0][0] if utc else "",
            domain_violation_pkts=sum(1 for r in win if r.get("g87251_domain_ok")=="0"),
            mcast_violation_pkts=sum(1 for r in win if r.get("g87251_mcast_ok")=="0"),
            cadence_sync_violation_pkts=sum(1 for r in win if r.get("g87251_log_sync_ok")=="0"),
            cadence_announce_violation_pkts=sum(1 for r in win if r.get("g87251_log_announce_ok")=="0"),
            path_trace_frac=round(sum(1 for r in ann if r.get("has_path_trace")=="1")/len(ann),4) if ann else "",
            interarrival_ms_mean=round(statistics.fmean(ia),4) if ia else "",
            interarrival_ms_std=round(statistics.pstdev(ia),4) if len(ia)>1 else "",
            telemetry_valid=1)
        w.writerow(rec); n+=1
    out.close(); return n

if __name__=="__main__":
    run_dir=sys.argv[1]
    ctx=json.load(open(os.path.join(run_dir,"context.json")))
    deep=[f for f in os.listdir(run_dir) if f.endswith("dn.deep.csv")]
    if not deep: print("no deep csv in",run_dir); sys.exit(1)
    out=os.path.join(run_dir,"windows.csv")
    n=build(os.path.join(run_dir,deep[0]),out,ctx["scenario"],ctx["class"],ctx["fault_id"])
    print(f"{ctx['scenario']}: {n} windows -> {out}")
