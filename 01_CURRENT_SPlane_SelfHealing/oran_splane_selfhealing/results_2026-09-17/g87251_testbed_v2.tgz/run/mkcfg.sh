#!/bin/bash
# Generate the per-node ptp4l configs from the shared G.8275.1 base.
#
# WHY THIS FILE EXISTS: the per-node configs (gma/gmb/bc/ru1..3.cfg) were referenced by
# run/start.sh but were NOT present in the shipped tarball, so the testbed could not be
# rebuilt from it. Values are reconstructed from the documented node roles in
# ORAN_SPlane_Testbed_Configuration_Reference.pdf section 4, and are now generated
# (and hashable) rather than hand-made.
#
# OPTION SCOPING verified against linuxptp v4.0 source config.c (the INSTALLED version):
#   clientOnly  -> GLOB_ITEM_INT  (global section only)      config.c:244
#   serverOnly  -> PORT_ITEM_INT  (per-port section)         config.c:324
#   masterOnly / slaveOnly are deprecated aliases            config.c:744-747
#
# Hierarchy uses priority2 - an operator-set BMCA input - because nothing in this lab is
# GNSS-traceable. Every node truthfully advertises clockClass 248 (no reference since
# startup). No node is given a fabricated clockClass 6.
set -euo pipefail
CFG=/opt/sptb/cfg
B=$CFG/g87251.base
server(){ local n=$1 p2=$2; shift 2
  { cat "$B"; printf '\npriority2                       %s\n' "$p2"; printf '%b' "$@"; } > "$CFG/$n.cfg"; }
client(){ local n=$1 p2=$2 port=$3
  { cat "$B"; printf '\npriority2                       %s\nclientOnly                      1\n[%s]\n' "$p2" "$port"; } > "$CFG/$n.cfg"; }
server gma 100 '[v-gma]\nserverOnly                      1\n'
server gmb 110 '[v-gmb]\nserverOnly                      1\n'
server bc  120 '[v-bc-up]\nserverOnly                      0\n[v-bc-dn]\nserverOnly                      1\n'
for r in ru1 ru2 ru3; do client $r 128 "v-$r"; done
echo "generated: $(ls $CFG/*.cfg | wc -l) per-node configs"
