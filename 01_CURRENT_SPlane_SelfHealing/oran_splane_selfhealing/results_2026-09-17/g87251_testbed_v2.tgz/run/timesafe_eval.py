#!/usr/bin/env python3
"""Cross-domain validation: apply the FROZEN decision rule (built and frozen on the
software testbed) to the REAL TIMESAFE hardware attack captures it has never seen.

Two independent claims, reported separately:

  (1) STANDARDS-ONLY (allow-list independent, zero provisioned context, nothing fitted):
      count real Announce that violate G.8275.1 priority1=128 or IEEE 1588 Table 5
      (clockClass 0-5 reserved), and show which source identity emits them. If the
      attacker's Announce violate the standard, the attack is detectable by conformance
      alone. This is the strongest claim because it needs no allow-list.

  (2) PROVENANCE (with a provisioned allow-list): allow-list = GM identities that emit
      STANDARDS-CONFORMANT Announce (priority1=128 AND clockClass>=6) - i.e. the clocks a
      correctly-provisioned operator would have listed. Then run the frozen decide() and
      report verdict + clause. The attacker, being non-conformant, is off this list.

The rule and its constants are unchanged from the frozen testbed artefact - verified by
hash before this runs.
"""
import csv, json, os, sys, importlib.util, collections, hashlib

HERE="/opt/sptb"
spec=importlib.util.spec_from_file_location("dr", os.path.join(HERE,"run/decision_rule.py"))
dr=importlib.util.module_from_spec(spec); spec.loader.exec_module(dr)

# verify the rule matches the frozen hash
frz=json.load(open(os.path.join(HERE,"FROZEN.json")))
h=hashlib.sha256(open(os.path.join(HERE,"run/decision_rule.py"),'rb').read()).hexdigest()
assert h==frz["artifacts"]["run/decision_rule.py"]["sha256"], "decision_rule.py != frozen hash"

CAPS=["2024-10-16-announce_attack","15min_announce_attack","prod_successful_announce_attack_ptp",
      "2024-10-08-announce_attack_1","2024-10-08-sync_attack_1","2024-10-08-sync_attack_singlestep_1"]

def load(path):
    return list(csv.DictReader(open(path,newline='',encoding='utf-8',errors='replace')))

results=[]
for name in CAPS:
    p=os.path.join(HERE,"timesafe",name+".deep.csv")
    if not os.path.exists(p): continue
    rows=load(p)
    ann=[r for r in rows if r.get("message_type")=="Announce"]
    # per-identity conformance
    by_id=collections.defaultdict(lambda: dict(n=0,p1=collections.Counter(),cc=collections.Counter()))
    for r in ann:
        sid=r.get("gm_clock_identity") or r.get("source_clock_identity") or "?"
        d=by_id[sid]; d["n"]+=1
        d["p1"][r.get("gm_priority1")]+=1; d["cc"][r.get("gm_clock_class")]+=1

    # (1) STANDARDS-ONLY legality violations, attributed to source identity
    def illegal_cc(r):
        v=r.get("gm_clock_class"); 
        return v not in ("",None) and int(v)<dr.IEEE1588_MIN_LEGAL_CLOCKCLASS
    def bad_p1(r):
        v=r.get("gm_priority1"); 
        return v not in ("",None) and int(v)!=dr.G87251_PRIORITY1
    viol=[r for r in ann if illegal_cc(r) or bad_p1(r)]
    viol_ids=collections.Counter((r.get("gm_clock_identity") or r.get("source_clock_identity")) for r in viol)
    conformant_ids=[sid for sid,d in by_id.items()
                    if d["p1"].get("128",0)==d["n"] and all(int(c)>=6 for c in d["cc"] if c not in ("",None))]

    # (2) PROVENANCE: provision the conformant GMs as the allow-list, run frozen decide()
    ctx=dict(gm_allowlist=conformant_ids or list(by_id)[:1],
             expected_bc_identity="__none__",
             expected_client_identities=[],
             expected_steps_removed_at_ru=1, maintenance_window_open=False)
    verdict,hint,why,ev=dr.decide(p,ctx)

    results.append(dict(
        capture=name, total_packets=len(rows), announce=len(ann),
        distinct_gm_ids=len(by_id),
        standards_only=dict(
            violating_announce=len(viol),
            attributed_to=dict(viol_ids),
            conformant_gm_ids=conformant_ids,
            detected_by_standards_alone=len(viol)>0),
        provenance=dict(allowlist_used=ctx["gm_allowlist"], verdict=verdict,
                        fault_hint=hint, clause=(why[0] if why else "")),
    ))

summary=dict(
    frozen_rule_sha256=h,
    captures_evaluated=len(results),
    detected_by_standards_alone=sum(1 for r in results if r["standards_only"]["detected_by_standards_alone"]),
    detected_as_attack_by_rule=sum(1 for r in results if r["provenance"]["verdict"]=="ATTACK"),
    results=results)
json.dump(summary,open(os.path.join(HERE,"results/TIMESAFE_CROSSVAL.json"),"w"),indent=2)
print(json.dumps({k:v for k,v in summary.items() if k!="results"},indent=2))
print("\nper capture:")
for r in results:
    s=r["standards_only"]
    print(f"  {r['capture'][:38]:40s} ann={r['announce']:>6} "
          f"| std-viol={s['violating_announce']:>6} -> {list(s['attributed_to'])} "
          f"| rule={r['provenance']['verdict']}/{r['provenance']['fault_hint']}")
