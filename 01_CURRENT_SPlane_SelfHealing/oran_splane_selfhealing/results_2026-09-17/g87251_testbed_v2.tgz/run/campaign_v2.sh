#!/bin/bash
# Randomised validation campaign. Usage: campaign_v2.sh <first_rep> <last_rep> <dur>
# Verifies frozen state, then runs every scenario once per rep with per-rep randomised
# parameters. Infrastructure failures (empty capture) are retried once then discarded with
# disclosure - never scored. Writes cap/<scen>__r<rep>/decision.json per run.
set -uo pipefail
FIRST="${1:-30}"; LAST="${2:-41}"; DUR="${3:-45}"
cd /opt/sptb
./run/verify_frozen.sh || { echo "ABORT: frozen state violated"; exit 1; }
SCEN="baseline A1_rogue_master A2_sync_spoof A3_replay A5_dos_flood A8_rogue_bc B2_gm_failover B_unplanned_failover B_bc_replacement B3_pdv_congestion B7_topology_change"
PROG=/opt/sptb/results/campaign_progress.log
hard_clean(){ pkill -f "ptp4l -f /opt/sptb" 2>/dev/null; pkill -f "tcpdump -i br" 2>/dev/null;
              pkill -f "run/flood.py" 2>/dev/null; pkill -f "run/inject.py" 2>/dev/null; sleep 1; }
for REP in $(seq $FIRST $LAST); do
 for s in $SCEN; do
  RUN="${s}__r${REP}"; ATT=0
  while [ $ATT -lt 2 ]; do
   ATT=$((ATT+1)); hard_clean
   ./run/mkcfg.sh >/dev/null 2>&1
   ./run/topology.sh >/dev/null 2>&1
   rm -rf cap/$s cap/$RUN
   ./run/pmc_log.sh $s $((DUR-5)) >/dev/null 2>&1 & PMC=$!
   ./run/scenarios.sh $s $DUR $REP >/dev/null 2>&1
   kill $PMC 2>/dev/null; wait $PMC 2>/dev/null
   mkdir -p cap/$RUN && cp -r cap/$s/. cap/$RUN/ 2>/dev/null
   PKTS=$(python3 ptp_deep_extract.py cap/$RUN/dn.pcap cap/$RUN/${RUN}.dn.deep.csv 2>/dev/null | grep -oE 'ptp=[0-9]+' | cut -d= -f2)
   if [ -z "$PKTS" ] || [ "$PKTS" -lt 100 ]; then
     rm -rf cap/$RUN
     [ $ATT -lt 2 ] && { echo "rep$REP $s INFRA-FAIL(${PKTS:-0}) retry" >>$PROG; continue; }
     echo "rep$REP $s RUN-FAILED-after-retry(${PKTS:-0}) discarded" >>$PROG; break
   fi
   python3 run/window_features.py cap/$RUN >/dev/null 2>&1
   python3 run/decision_rule.py cap/$RUN >/dev/null 2>&1
   v=$(python3 -c "import json;d=json.load(open('cap/$RUN/decision.json'));print(d['verdict'],d['truth_class'],d.get('fault_hint'))" 2>/dev/null || echo FAIL)
   echo "rep$REP $s -> $v (${PKTS}pk)" >>$PROG
   break
  done
 done
 echo "=== rep $REP complete $(date -u +%H:%M:%S) ===" >>$PROG
done
echo "CAMPAIGN COMPLETE $(date -u +%Y-%m-%dT%H:%M:%SZ)" >>$PROG
