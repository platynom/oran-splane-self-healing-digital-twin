#!/bin/bash
# One replicate of every scenario. Usage: run_rep.sh <rep> <dur>
set -uo pipefail
REP="${1:-1}"; DUR="${2:-45}"; cd /opt/sptb
SCEN="baseline A1_rogue_master A2_sync_spoof A3_replay A5_dos_flood A8_rogue_bc B2_gm_failover B3_pdv_congestion B7_topology_change"
# Hard cleanup: a ptp4l/tcpdump surviving from the previous scenario can hold a namespace
# open and make the next topology rebuild race, yielding an empty capture.
hard_clean(){ pkill -f "ptp4l -f /opt/sptb" 2>/dev/null; pkill -f "tcpdump -i br" 2>/dev/null; sleep 1; }

for s in $SCEN; do
  RUN="${s}__r${REP}"
  ATTEMPT=0
  while [ $ATTEMPT -lt 2 ]; do
  ATTEMPT=$((ATTEMPT+1))
  hard_clean
  ./run/topology.sh >/dev/null 2>&1
  rm -rf cap/$s cap/$RUN
  ./run/pmc_log.sh $s $((DUR-5)) >/dev/null 2>&1 &
  PMC=$!
  ./run/scenarios.sh $s $DUR >/dev/null 2>&1
  kill $PMC 2>/dev/null; wait $PMC 2>/dev/null
  mkdir -p cap/$RUN && cp -r cap/$s/. cap/$RUN/ 2>/dev/null
  # reject an infrastructure failure instead of scoring it as a detection result
  PKTS=$(python3 ptp_deep_extract.py cap/$RUN/dn.pcap cap/$RUN/${RUN}.dn.deep.csv 2>/dev/null | grep -oE 'ptp=[0-9]+' | cut -d= -f2)
  if [ -z "$PKTS" ] || [ "$PKTS" -lt 100 ]; then
    rm -rf cap/$RUN
    if [ $ATTEMPT -lt 2 ]; then
      echo "  rep$REP $s -> infrastructure failure (${PKTS:-0} PTP pkts); retrying once"
      continue
    fi
    echo "  rep$REP $s -> RUN FAILED after retry (${PKTS:-0} PTP pkts - infrastructure, not detection); discarded"
    break
  fi
  python3 run/window_features.py cap/$RUN >/dev/null 2>&1
  python3 run/decision_rule.py cap/$RUN >/dev/null 2>&1
  v=$(python3 -c "import json;d=json.load(open('cap/$RUN/decision.json'));print(d['verdict'],d['truth_class'])" 2>/dev/null || echo "FAIL")
  printf "  rep%s %-22s -> %s\n" "$REP" "$s" "$v"
  break
  done
done
