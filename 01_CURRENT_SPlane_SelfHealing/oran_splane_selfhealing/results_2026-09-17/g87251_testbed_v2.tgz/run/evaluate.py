#!/usr/bin/env python3
"""
Session-disjoint evaluation of the FROZEN decision rule.

PRE-REGISTERED EXPECTED VERDICTS (defined by each scenario's NATURE, before any aggregate
result exists - this is pre-registration, not post-hoc tuning). Three verdict classes:

  ATTACK-expected  : A1,A2,A3,A5,A8            -> correct verdict ATTACK   (sensitivity)
  BENIGN-expected  : baseline,B2,B_bc_replacement,B3,B7
                                               -> correct verdict BENIGN   (specificity)
  ABSTAIN-expected : B_unplanned_failover      -> correct verdict UNKNOWN  (abstention)

Why B_unplanned_failover expects UNKNOWN. A grandmaster crashing with NO maintenance window,
replaced by a provisioned backup, is - from the packets alone - indistinguishable from an
attack that suppressed the master. The scientifically honest verdict is abstention, NOT a
benign call. Scoring its UNKNOWN as a specificity failure would PENALISE honesty; scoring a
BENIGN call as success would REWARD over-claiming. So it is scored on a separate axis:
abstention-correctness = fraction that returned UNKNOWN. A BENIGN here is a dangerous
over-claim; an ATTACK here is a false alarm. Both are failures on this axis.

* Development runs (reps in FROZEN.json development_reps, or unnumbered) are EXCLUDED.
* Splits are by RUN. Wilson 95% CIs. Under-powered classes -> NOT ESTABLISHED with widths.
* decision_rule.py is unchanged from the prior freeze (hash verified); only this scoring
  file's semantics were corrected, before any aggregate was computed.
"""
from __future__ import annotations
import json, os, glob, math, sys, collections

EXPECT = {
    "A1_rogue_master":"ATTACK","A2_sync_spoof":"ATTACK","A3_replay":"ATTACK",
    "A5_dos_flood":"ATTACK","A8_rogue_bc":"ATTACK",
    "baseline":"BENIGN","B2_gm_failover":"BENIGN","B_bc_replacement":"BENIGN",
    "B3_pdv_congestion":"BENIGN","B7_topology_change":"BENIGN",
    "B_unplanned_failover":"UNKNOWN",
}

def wilson(k,n,z=1.96):
    if n==0: return (None,None,None)
    p=k/n; d=1+z*z/n; c=(p+z*z/(2*n))/d
    h=z*math.sqrt(p*(1-p)/n+z*z/(4*n*n))/d
    return (round(p,4),round(max(0,c-h),4),round(min(1,c+h),4))

def fmt(name,est,n):
    if n==0: return f"{name}: NOT ESTABLISHED (no runs)"
    p,lo,hi=est; s=f"{name}: {p:.3f}  95% CI [{lo:.3f}, {hi:.3f}]  n={n}"
    if hi-lo>0.4: s+="  <- NOT ESTABLISHED (interval too wide)"
    return s

def main(cap_root="/opt/sptb/cap", frozen="/opt/sptb/FROZEN.json"):
    dev_reps=set(json.load(open(frozen)).get("development_reps",[])) if os.path.exists(frozen) else set()
    runs=[]
    for d in sorted(glob.glob(os.path.join(cap_root,"*"))):
        cj,dj=os.path.join(d,"context.json"),os.path.join(d,"decision.json")
        if not (os.path.exists(cj) and os.path.exists(dj)): continue
        ctx=json.load(open(cj)); dec=json.load(open(dj)); base=os.path.basename(d)
        rep=int(base.split("__r")[-1]) if "__r" in base and base.split("__r")[-1].isdigit() else None
        sc=ctx["scenario"]
        runs.append(dict(run=base,scenario=sc,rep=rep,truth=ctx["class"],fault=ctx["fault_id"],
                         verdict=dec["verdict"],hint=dec.get("fault_hint"),
                         expect=EXPECT.get(sc,"?"),
                         is_dev=(rep in dev_reps) or rep is None))
    val=[r for r in runs if not r["is_dev"]]; excl=[r for r in runs if r["is_dev"]]
    A=[r for r in val if r["expect"]=="ATTACK"]
    B=[r for r in val if r["expect"]=="BENIGN"]
    U=[r for r in val if r["expect"]=="UNKNOWN"]

    tp=sum(1 for r in A if r["verdict"]=="ATTACK"); fn=sum(1 for r in A if r["verdict"]=="BENIGN"); ua=sum(1 for r in A if r["verdict"]=="UNKNOWN")
    tn=sum(1 for r in B if r["verdict"]=="BENIGN"); fp=sum(1 for r in B if r["verdict"]=="ATTACK"); ub=sum(1 for r in B if r["verdict"]=="UNKNOWN")
    abst=sum(1 for r in U if r["verdict"]=="UNKNOWN"); over=sum(1 for r in U if r["verdict"]=="BENIGN"); fa=sum(1 for r in U if r["verdict"]=="ATTACK")

    sens=wilson(tp,len(A)); spec=wilson(tn,len(B)); abr=wilson(abst,len(U))
    att_ok=sum(1 for r in A if r["hint"]==r["fault"]); a_est=wilson(att_ok,len(A))

    print("="*80); print("SESSION-DISJOINT EVALUATION OF THE FROZEN RULE (randomised campaign)"); print("="*80)
    print(f"excluded (dev/unnumbered): {len(excl)}   admissible reps: {sorted(set(r['rep'] for r in val))}")
    print(f"validation runs: {len(val)}  (attack-expected={len(A)}, benign-expected={len(B)}, abstain-expected={len(U)})")
    if not val:
        print("\nNOT ESTABLISHED: zero admissible validation runs."); return
    print(f"\nATTACK-expected  : TP={tp} FN={fn} UNKNOWN={ua}")
    print(f"BENIGN-expected  : TN={tn} FP={fp} UNKNOWN={ub}")
    print(f"ABSTAIN-expected : correct-UNKNOWN={abst} over-claim-BENIGN={over} false-alarm-ATTACK={fa}")
    print("\n"+fmt("sensitivity (attack recall)",sens,len(A)))
    print(fmt("specificity (decidable-benign recall)",spec,len(B)))
    print(fmt("abstention correctness (ambiguous benign -> UNKNOWN)",abr,len(U)))
    print(fmt("attack attribution accuracy (correct fault id)",a_est,len(A)))
    per=collections.defaultdict(lambda:[0,0])
    for r in A:
        per[r["fault"]][1]+=1
        if r["hint"]==r["fault"]: per[r["fault"]][0]+=1
    print("  per-fault attribution:", "  ".join(f"{k}={v[0]}/{v[1]}" for k,v in sorted(per.items())))
    # honest overall-power note
    if len(A)<8 or len(B)<8:
        print(f"\nNOTE: attack n={len(A)}, benign n={len(B)}. Small n widens CIs; read the bounds, not the point.")
    print("\nper-run detail (only mismatches shown):")
    for r in val:
        ok = r["verdict"]==r["expect"]
        if not ok:
            print(f"  [MISS] {r['run']:26s} expect={r['expect']:7s} got={r['verdict']:8s} ({r['hint']})")
    print("  (all other runs matched their pre-registered expected verdict)")
    json.dump(dict(
        expected_verdict_map=EXPECT,
        counts=dict(tp=tp,fn=fn,unknown_attack=ua,tn=tn,fp=fp,unknown_benign=ub,
                    abstain_correct=abst,abstain_overclaim=over,abstain_falsealarm=fa),
        sensitivity=sens,specificity=spec,abstention_correctness=abr,attribution_accuracy=a_est,
        per_fault={k:v for k,v in per.items()},
        admissible_reps=sorted(set(r['rep'] for r in val)),
        excluded=[r['run'] for r in excl],
        validation=val),
        open("/opt/sptb/results/EVALUATION.json","w"),indent=2)
    print("\n-> /opt/sptb/results/EVALUATION.json")

if __name__=="__main__": main(*(sys.argv[1:] or []))
