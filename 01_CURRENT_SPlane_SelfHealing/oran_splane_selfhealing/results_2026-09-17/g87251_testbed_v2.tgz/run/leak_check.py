#!/usr/bin/env python3
"""Provenance-leak detector.

PURPOSE. When benign data comes from one apparatus and attack data from another, any
field that differs systematically between the two apparatuses becomes a perfect
classifier that learns nothing about attacks. This project has already been bitten three
times: the 16x Announce-cadence confound, offset_scaled_log_variance 4096-vs-65535, and
(caught pre-run) PATH_TRACE presence. This tool makes that check systematic instead of
anecdotal.

METHOD. For every column, compute the value sets on each side. Report:
  DISJOINT   - value sets share nothing: a single equality test separates the corpora 100%.
  NEAR       - Jaccard overlap below --near: almost separates.
  OK         - substantial overlap.
Only columns that are CONSTANT-ish per side can leak this way, so the count of distinct
values is reported to distinguish a true leak from a high-cardinality field (timestamps,
sequence ids) that trivially "disjoints" without being a usable shortcut.

Exit status 1 if any DISJOINT column is found that is not on the expected-difference list.
"""
from __future__ import annotations
import csv, sys, argparse, collections

# Fields that MUST differ between two independent captures and are not usable shortcuts:
# they are per-capture nonces, clock values or device identities, not apparatus signatures.
EXPECTED_DIFFERENT = {
    "capture_ts_ns", "sequence_id", "origin_ts_ns", "correction_ns",
    "eth_src", "source_clock_identity", "gm_clock_identity",
    "requesting_clock_identity", "source_port_number", "requesting_port_number",
    "message_length",
}

def load(paths, cap=None):
    vals = collections.defaultdict(set)
    n = 0
    for p in paths:
        with open(p, newline='', encoding='utf-8', errors='replace') as f:
            for row in csv.DictReader(f):
                n += 1
                for k, v in row.items():
                    if len(vals[k]) < 5000:
                        vals[k].add(v)
                if cap and n >= cap:
                    break
    return vals, n

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--a", nargs="+", required=True, help="corpus A csvs")
    ap.add_argument("--b", nargs="+", required=True, help="corpus B csvs")
    ap.add_argument("--a-name", default="A"); ap.add_argument("--b-name", default="B")
    ap.add_argument("--near", type=float, default=0.02)
    ap.add_argument("--cap", type=int, default=0)
    args = ap.parse_args()
    A, na = load(args.a, args.cap or None)
    B, nb = load(args.b, args.cap or None)
    print(f"{args.a_name}: {na} rows, {len(A)} cols | {args.b_name}: {nb} rows, {len(B)} cols\n")
    leaks, near = [], []
    for k in sorted(set(A) | set(B)):
        sa, sb = A.get(k, set()), B.get(k, set())
        if not sa or not sb:
            continue
        inter, union = sa & sb, sa | sb
        j = len(inter) / len(union) if union else 1.0
        tag = "OK"
        if not inter:
            tag = "DISJOINT"
        elif j < args.near:
            tag = "NEAR"
        if tag != "OK":
            row = (k, tag, len(sa), len(sb), round(j, 4),
                   sorted(sa)[:3] if len(sa) <= 6 else f"{len(sa)} values",
                   sorted(sb)[:3] if len(sb) <= 6 else f"{len(sb)} values")
            (leaks if tag == "DISJOINT" else near).append(row)
    hdr = f"{'column':34s} {'verdict':9s} {'|A|':>6s} {'|B|':>6s} {'jacc':>7s}  A-sample / B-sample"
    print(hdr); print("-" * len(hdr))
    unexpected = 0
    for k, tag, la, lb, j, ea, eb in leaks + near:
        flag = "" if k in EXPECTED_DIFFERENT else "  <== UNEXPECTED"
        if flag: unexpected += 1
        print(f"{k:34s} {tag:9s} {la:6d} {lb:6d} {j:7.4f}  {ea} / {eb}{flag}")
    if not leaks and not near:
        print("(none)")
    print(f"\nDISJOINT={len(leaks)}  NEAR={len(near)}  UNEXPECTED={unexpected}")
    return 1 if unexpected else 0

if __name__ == "__main__":
    sys.exit(main())
