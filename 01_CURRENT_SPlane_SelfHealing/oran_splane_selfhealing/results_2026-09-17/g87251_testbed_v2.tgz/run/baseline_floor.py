#!/usr/bin/env python3
"""
Instrument noise-floor characterisation.

Derived thresholds are meaningless without a measured denominator. This computes the
floor from N healthy baseline runs and expresses it the way ITU-T G.8260 defines packet
timing metrics (percentile/floor statistics), so later thresholds can be stated as
multiples of a MEASURED floor rather than as absolute nanoseconds the testbed cannot
legitimately claim.
"""
from __future__ import annotations
import csv, sys, os, glob, json, statistics

METRICS=["interarrival_ms_mean","interarrival_ms_std","msg_rate_hz",
         "announce_rate_hz","sync_rate_hz","correction_ns_mean","correction_ns_max"]

def pct(v,p):
    if not v: return None
    s=sorted(v); k=(len(s)-1)*p/100.0; lo=int(k); hi=min(lo+1,len(s)-1)
    return s[lo]+(s[hi]-s[lo])*(k-lo)

def main(baseline_dirs,out_json):
    vals={m:[] for m in METRICS}; nwin=0; runs=[]
    for d in baseline_dirs:
        w=os.path.join(d,"windows.csv")
        if not os.path.exists(w): continue
        runs.append(os.path.basename(d))
        for r in csv.DictReader(open(w)):
            nwin+=1
            for m in METRICS:
                try: vals[m].append(float(r[m]))
                except: pass
    floor={}
    for m,v in vals.items():
        if not v: floor[m]={"n":0,"note":"not observed in baseline"}; continue
        floor[m]=dict(n=len(v),mean=round(statistics.fmean(v),6),
                      sd=round(statistics.pstdev(v),6) if len(v)>1 else None,
                      p50=round(pct(v,50),6),p95=round(pct(v,95),6),
                      p99=round(pct(v,99),6),max=round(max(v),6))
    doc=dict(n_baseline_runs=len(runs),runs=runs,n_windows=nwin,
             method=("Floor computed from healthy baseline runs only. Metric definitions follow "
                     "ITU-T G.8260 (definitions and terminology for synchronization in packet networks). "
                     "Thresholds MUST be expressed as multiples of these values, never as absolute ns."),
             caveat=("Software timestamping only. veth reports 'PTP Hardware Clock: none'. "
                     "This floor is an INSTRUMENT property, not a network property, and cannot "
                     "support any conformance claim against G.8273.2 / G.8271.1."),
             floor=floor)
    json.dump(doc,open(out_json,"w"),indent=2)
    print(json.dumps({k:(v if k!="floor" else "...") for k,v in doc.items()},indent=2))
    print(f"\nfloor over {nwin} windows from {len(runs)} baseline run(s) -> {out_json}")
    for m,s in floor.items():
        if s.get("n"): print(f"  {m:26s} p50={s['p50']:<12} p95={s['p95']:<12} max={s['max']}")

if __name__=="__main__":
    dirs=sys.argv[1:-1] or sorted(glob.glob("/opt/sptb/cap/baseline*"))
    out=sys.argv[-1] if len(sys.argv)>1 else "/opt/sptb/NOISE_FLOOR.json"
    main(dirs,out)
