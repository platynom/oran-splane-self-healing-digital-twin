#!/usr/bin/env python3
"""Analyse the live coverage-gap captures: characterise the injected disturbance,
then apply the FROZEN rule and decision_rule_v2. Writes GAP_COVERAGE_LIVE.json."""
import importlib.util, json, csv, collections, hashlib, os, datetime

SP="/opt/sptb"
def load(name):
    spec=importlib.util.spec_from_file_location(name, f"{SP}/run/{name}.py")
    m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m); return m
dr=load("decision_rule")
v2=load("decision_rule_v2")

# frozen hash gate
frz=json.load(open(f"{SP}/FROZEN.json"))
h=hashlib.sha256(open(f"{SP}/run/decision_rule.py","rb").read()).hexdigest()
assert h==frz["artifacts"]["run/decision_rule.py"]["sha256"], "frozen hash mismatch"

def H(p): return hashlib.sha256(open(p,'rb').read()).hexdigest()

CASES=[("LIVE_baseline","BENIGN (control)"),
       ("C1_removal","ATTACK (interception)"),
       ("C2_malformed","ATTACK (fuzz)"),
       ("C3_wholesecond","ATTACK (whole-second)")]

def characterise(sc, rows):
    d={}
    d["n_ptp"]=len(rows)
    ts=[int(r["capture_ts_ns"]) for r in rows if r.get("capture_ts_ns")]
    span=(max(ts)-min(ts))/1e9 if len(ts)>1 else 0
    d["span_s"]=round(span,1)
    if sc=="C1_removal":
        # BC downstream Sync rate over the whole span (loss window depresses it)
        bc="020000fffe000001"
        sync=[r for r in rows if r["message_type"]=="Sync" and r.get("source_clock_identity")==bc]
        d["bc_sync_n"]=len(sync); d["bc_sync_rate_hz"]=round(len(sync)/span,2) if span else None
        d["bc_sync_declared"]=collections.Counter(r["log_message_interval"] for r in sync)
    if sc=="C2_malformed":
        d["version_ptp"]=dict(collections.Counter(r["version_ptp"] for r in rows))
        d["control_gt5"]=sum(1 for r in rows if r.get("control_field") not in ("",None) and r["control_field"].isdigit() and int(r["control_field"])>5)
        d["msgtype_raw"]=dict(collections.Counter(r["message_type_raw"] for r in rows))
        d["len_lt_min"]=sum(1 for r in rows if r.get("message_length") not in ("",None) and r["message_length"].isdigit() and int(r["message_length"])<44)
    if sc=="C3_wholesecond":
        ann=[r for r in rows if r["message_type"]=="Announce"]
        d["announce_n"]=len(ann)
        d["leap61_set"]=sum(1 for r in ann if r.get("flag_leap61")=="1")
        d["utc_offsets"]=dict(collections.Counter(r["current_utc_offset"] for r in ann))
    return d

out=dict(title="Coverage-gap closure - LIVE on-wire validation",
    generated=datetime.datetime.utcnow().isoformat()+"Z",
    method="Real linuxptp 4.0 G.8275.1 testbed in network namespaces; faults produced on the wire "
           "(tc netem loss / scapy injection). NOT crafted CSVs. decision_rule_v2 is UNFROZEN dev.",
    frozen_rule=dict(sha256=h, matches_FROZEN_json=True),
    linuxptp="4.0", cases={})

for sc,truth in CASES:
    d=f"{SP}/cap/{sc}"
    csvf=[f for f in os.listdir(d) if f.endswith(".dn.deep.csv")][0]
    p=os.path.join(d,csvf)
    rows=list(csv.DictReader(open(p)))
    ctx=json.load(open(os.path.join(d,"context.json")))
    fv,fh,fw,fev=dr.decide(p,ctx)
    vv,vh,vw,vev=v2.decide_v2(p,ctx)
    out["cases"][sc]=dict(truth=truth, capture_sha256=H(p), deep_csv=csvf,
        disturbance=characterise(sc,rows),
        frozen=dict(verdict=fv,hint=fh,clause=(fw[0][:140] if fw else "")),
        v2=dict(verdict=vv,hint=vh,clause=(vw[0][:140] if vw else "")))

json.dump(out, open(f"{SP}/results/GAP_COVERAGE_LIVE.json","w"), indent=2)

# console summary
print("=== LIVE coverage-gap validation (linuxptp 4.0, on-wire) ===")
print(f"frozen hash OK: {out['frozen_rule']['matches_FROZEN_json']}\n")
for sc,truth in CASES:
    c=out["cases"][sc]
    print(f"{sc:16s} [{truth}]")
    print(f"   frozen: {c['frozen']['verdict']:7s} {str(c['frozen']['hint'])}")
    print(f"   v2    : {c['v2']['verdict']:7s} {str(c['v2']['hint'])}")
    print(f"   disturbance: {c['disturbance']}")
print("\n[results/GAP_COVERAGE_LIVE.json written]")
