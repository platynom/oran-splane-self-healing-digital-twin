#!/usr/bin/env python3
"""Tabulate frozen-rule vs v2 across all archived live reps; write GAP_COVERAGE_LIVE.json."""
import importlib.util, json, csv, hashlib, os, glob, datetime, collections
SP="/opt/sptb"
def load(n):
    s=importlib.util.spec_from_file_location(n,f"{SP}/run/{n}.py")
    m=importlib.util.module_from_spec(s); s.loader.exec_module(m); return m
dr=load("decision_rule"); v2=load("decision_rule_v2")
frz=json.load(open(f"{SP}/FROZEN.json"))
h=hashlib.sha256(open(f"{SP}/run/decision_rule.py","rb").read()).hexdigest()
assert h==frz["artifacts"]["run/decision_rule.py"]["sha256"]
def H(p): return hashlib.sha256(open(p,'rb').read()).hexdigest()

SCEN={"baseline":"BENIGN (control)","C1_removal":"ATTACK item1 interception",
      "C2_malformed":"ATTACK item2 malformed","C3_wholesecond":"ATTACK item3 whole-second"}
EXPECT_FROZEN={"baseline":"BENIGN","C1_removal":"BENIGN","C2_malformed":"BENIGN","C3_wholesecond":"BENIGN"}
EXPECT_V2={"baseline":"BENIGN","C1_removal":"ATTACK","C2_malformed":"ATTACK","C3_wholesecond":"ATTACK"}

out=dict(title="Coverage-gap closure - LIVE on-wire validation (reproducibility)",
    generated=datetime.datetime.utcnow().isoformat()+"Z",
    method="Real linuxptp 4.0 G.8275.1 testbed in netns; faults on the wire (link blackhole / "
           "scapy injection; netem unavailable in kernel). NOT crafted CSVs. v2 is UNFROZEN dev.",
    frozen_sha256=h, frozen_matches=True, linuxptp="4.0", reps=[])

rows_tbl=[]
for rep in (1,2):
    for sc in ["baseline","C1_removal","C2_malformed","C3_wholesecond"]:
        d=f"{SP}/cap/{sc}__live_r{rep}"
        if not os.path.isdir(d): continue
        cs=[f for f in os.listdir(d) if f.endswith(".dn.deep.csv")]
        if not cs:
            rows_tbl.append((rep,sc,"NO_CSV","-")); continue
        p=os.path.join(d,cs[0]); ctx=json.load(open(os.path.join(d,"context.json")))
        fv=dr.decide(p,ctx)[0]; vv=v2.decide_v2(p,ctx)[0]
        rows_tbl.append((rep,sc,fv,vv))
        out["reps"].append(dict(rep=rep,scenario=sc,truth=SCEN[sc],
            frozen=fv,v2=vv,capture_sha256=H(p),
            frozen_as_expected=(fv==EXPECT_FROZEN[sc]),
            v2_as_expected=(vv==EXPECT_V2[sc])))

json.dump(out,open(f"{SP}/results/GAP_COVERAGE_LIVE.json","w"),indent=2)

print("=== LIVE reproducibility (linuxptp 4.0, on-wire) ===")
print(f"frozen hash OK: {out['frozen_matches']}\n")
print(f"{'rep':>3} {'scenario':16} {'frozen':8} {'v2':8} {'verdict':>10}")
allok=True
for rep,sc,fv,vv in rows_tbl:
    ok = (fv==EXPECT_FROZEN.get(sc)) and (vv==EXPECT_V2.get(sc))
    allok = allok and ok
    print(f"{rep:>3} {sc:16} {fv:8} {vv:8} {'OK' if ok else 'CHECK':>10}")
# aggregate
frozen_miss=sum(1 for r,s,f,v in rows_tbl if s!='baseline' and f=='BENIGN')
v2_catch=sum(1 for r,s,f,v in rows_tbl if s!='baseline' and v=='ATTACK')
n_atk=sum(1 for r,s,f,v in rows_tbl if s!='baseline')
n_base=sum(1 for r,s,f,v in rows_tbl if s=='baseline')
base_fp_frozen=sum(1 for r,s,f,v in rows_tbl if s=='baseline' and f!='BENIGN')
base_fp_v2=sum(1 for r,s,f,v in rows_tbl if s=='baseline' and v!='BENIGN')
print(f"\nfrozen MISSED {frozen_miss}/{n_atk} attack runs (expected: all - these are the gaps)")
print(f"v2 CAUGHT     {v2_catch}/{n_atk} attack runs")
print(f"baseline false-positives: frozen {base_fp_frozen}/{n_base}, v2 {base_fp_v2}/{n_base}")
print(f"\nALL AS EXPECTED: {allok}")
print("[results/GAP_COVERAGE_LIVE.json written]")
