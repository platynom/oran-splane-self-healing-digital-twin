#!/bin/bash
# Reproducibility driver: run baseline + the 3 coverage scenarios REPS times,
# archiving each capture under cap/<sc>__live_r<rep> for preservation + hashing.
set -uo pipefail
cd /opt/sptb
REPS="${1:-2}"
for rep in $(seq 1 $REPS); do
  # baseline via the standard harness (topology + scenario)
  bash ./run/clean_all.sh >/dev/null 2>&1
  bash ./run/topology.sh >/dev/null 2>&1
  bash ./run/scenarios.sh baseline 30 $((900+rep)) >/dev/null 2>&1
  python3 ptp_deep_extract.py cap/baseline/dn.pcap cap/baseline/baseline.dn.deep.csv >/dev/null 2>&1
  rm -rf cap/baseline__live_r${rep}; mkdir -p cap/baseline__live_r${rep}
  cp -r cap/baseline/. cap/baseline__live_r${rep}/
  # 3 coverage scenarios
  for sc in C1_removal C2_malformed C3_wholesecond; do
    D=34; [ "$sc" = "C1_removal" ] && D=44
    bash ./run/run_gap.sh $sc $D >/dev/null 2>&1
    rm -rf cap/${sc}__live_r${rep}; mkdir -p cap/${sc}__live_r${rep}
    cp -r cap/$sc/. cap/${sc}__live_r${rep}/
    echo "rep$rep $sc archived"
  done
done
echo "run_reps complete ($REPS reps)"
