#!/usr/bin/env python3
"""
campaign_v3 evaluation: score BOTH the frozen rule and frozen v2 across all runs, with the
SAME pre-registered EXPECT map (extended with the 3 coverage scenarios). Wilson 95% CIs.

EXPECT (pre-registered by scenario nature):
  ATTACK : A1,A2,A3,A5,A8, C1_removal,C2_malformed,C3_wholesecond
  BENIGN : baseline,B2_gm_failover,B_bc_replacement,B3_pdv_congestion,B7_topology_change
  UNKNOWN: B_unplanned_failover   (honest abstention; scored on its own axis)

Reports frozen vs v2 side by side. The point of the campaign: v2 must (a) close the 3
coverage gaps (frozen sensitivity 0 -> v2 high on C*), and (b) NOT regress the frozen rule
on any existing scenario (additive-only).
"""
import json, os, glob, math, collections

EXPECT = {
 "A1_rogue_master":"ATTACK","A2_sync_spoof":"ATTACK","A3_replay":"ATTACK",
 "A5_dos_flood":"ATTACK","A8_rogue_bc":"ATTACK",
 "C1_removal":"ATTACK","C2_malformed":"ATTACK","C3_wholesecond":"ATTACK",
 "baseline":"BENIGN","B2_gm_failover":"BENIGN","B_bc_replacement":"BENIGN",
 "B3_pdv_congestion":"BENIGN","B7_topology_change":"BENIGN",
 "B_unplanned_failover":"UNKNOWN",
}
def wilson(k,n,z=1.96):
    if n==0: return (None,None,None)
    p=k/n; d=1+z*z/n; c=(p+z*z/(2*n))/d
    h=z*math.sqrt(p*(1-p)/n+z*z/(4*n*n))/d
    return (round(p,4),round(max(0,c-h),4),round(min(1,c+h),4))
def fmt(name,est,n):
    if n==0 or est[0] is None: return f"{name}: NOT ESTABLISHED (n=0)"
    p,lo,hi=est; s=f"{name}: {p:.3f}  95% CI [{lo:.3f},{hi:.3f}]  n={n}"
    if hi-lo>0.4: s+="  <- wide"
    return s

def load_runs(decfile):
    runs=[]
    for d in sorted(glob.glob("/opt/sptb/cap/*__r*")):
        cj=os.path.join(d,"context.json"); dj=os.path.join(d,decfile)
        # campaign_v3 runs only: identified by the presence of decision_v2.json, so BOTH
        # rules are scored on the SAME run set (excludes prior-campaign reps r30-r41).
        if not os.path.exists(os.path.join(d,"decision_v2.json")): continue
        if not (os.path.exists(cj) and os.path.exists(dj)): continue
        ctx=json.load(open(cj)); dec=json.load(open(dj)); base=os.path.basename(d)
        sc=ctx["scenario"]
        if sc not in EXPECT: continue
        runs.append(dict(run=base,scenario=sc,truth=ctx["class"],fault=ctx["fault_id"],
            verdict=dec["verdict"],hint=dec.get("fault_hint"),expect=EXPECT[sc]))
    return runs

def score(runs,label):
    A=[r for r in runs if r["expect"]=="ATTACK"]
    B=[r for r in runs if r["expect"]=="BENIGN"]
    U=[r for r in runs if r["expect"]=="UNKNOWN"]
    tp=sum(1 for r in A if r["verdict"]=="ATTACK"); fn=sum(1 for r in A if r["verdict"]=="BENIGN"); ua=sum(1 for r in A if r["verdict"]=="UNKNOWN")
    tn=sum(1 for r in B if r["verdict"]=="BENIGN"); fp=sum(1 for r in B if r["verdict"]=="ATTACK"); ub=sum(1 for r in B if r["verdict"]=="UNKNOWN")
    ab=sum(1 for r in U if r["verdict"]=="UNKNOWN")
    out=dict(label=label,n_attack=len(A),n_benign=len(B),n_unknown=len(U),
        tp=tp,fn=fn,unknown_on_attack=ua,tn=tn,fp=fp,unknown_on_benign=ub,abstain_correct=ab,
        sensitivity=wilson(tp,len(A)),specificity=wilson(tn,len(B)),abstention=wilson(ab,len(U)))
    # per-scenario sensitivity (attack scenarios only)
    per={}
    bysc=collections.defaultdict(list)
    for r in A: bysc[r["scenario"]].append(r)
    for sc,rr in sorted(bysc.items()):
        k=sum(1 for r in rr if r["verdict"]=="ATTACK"); per[sc]=(k,len(rr),wilson(k,len(rr)))
    out["per_scenario_sensitivity"]=per
    return out

frozen=load_runs("decision.json")
v2=load_runs("decision_v2.json")
sf=score(frozen,"FROZEN rule (c362e11)")
sv=score(v2,"FROZEN v2 (e32eb65b)")

def show(s):
    print("\n"+"="*78); print(s["label"]); print("="*78)
    print(f"attack n={s['n_attack']}  benign n={s['n_benign']}  unknown n={s['n_unknown']}")
    print(f"ATTACK-expected: TP={s['tp']} FN={s['fn']} UNKNOWN={s['unknown_on_attack']}")
    print(f"BENIGN-expected: TN={s['tn']} FP={s['fp']} UNKNOWN={s['unknown_on_benign']}")
    print(fmt("  sensitivity (attack recall)",s["sensitivity"],s["n_attack"]))
    print(fmt("  specificity (benign recall) ",s["specificity"],s["n_benign"]))
    print(fmt("  abstention correctness      ",s["abstention"],s["n_unknown"]))
    print("  per-attack-scenario recall:")
    for sc,(k,n,ci) in s["per_scenario_sensitivity"].items():
        print(f"    {sc:18s} {k}/{n}  {fmt('',ci,n).strip()}")

show(sf); show(sv)
print("\n"+"="*78); print("HEADLINE: coverage-gap closure (frozen -> v2)"); print("="*78)
for sc in ["C1_removal","C2_malformed","C3_wholesecond"]:
    f=sf["per_scenario_sensitivity"].get(sc,(0,0,(None,)*3)); v=sv["per_scenario_sensitivity"].get(sc,(0,0,(None,)*3))
    print(f"  {sc:18s} frozen {f[0]}/{f[1]}  ->  v2 {v[0]}/{v[1]}")
print(f"\n  frozen overall sensitivity {sf['sensitivity'][0]}  ->  v2 {sv['sensitivity'][0]}")
print(f"  specificity frozen {sf['specificity'][0]}  v2 {sv['specificity'][0]}  (equal = additive-only, no regression)")

json.dump(dict(frozen=sf,v2=sv,expect=EXPECT),open("/opt/sptb/results/EVALUATION_V3.json","w"),indent=2)
print("\n-> /opt/sptb/results/EVALUATION_V3.json")
